# new feature — only in right
def new_func():
    return 42
