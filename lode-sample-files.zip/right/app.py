VERSION = '1.0.0'
DEBUG = False
MAX_RETRIES = 5
TIMEOUT = 30

def run():
    print('starting v1.0')
    print('production mode')
