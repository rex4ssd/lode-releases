def say_hello(name: str) -> str:
    """Return a hello greeting."""
    return f"Hello, {name}!"

if __name__ == "__main__":
    print(say_hello("Lode reviewer"))
