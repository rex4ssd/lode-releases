# Meeting Notes

Hello team,

Today's agenda:
- Review PR #42
- Deploy staging
- Hello from the new hire
