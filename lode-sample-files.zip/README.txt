Lode Sample Files — App Review Package
=======================================

HOW TO USE
----------
1. VIEWER (⌘1)
   Drag sample.csv, sample.xlsx, or sample.docx into Lode.

2. FOLDER COMPARE (⌘3)
   Press ⌘3. Drag 'left/' into left pane, 'right/' into right pane.
   Differences: app.py (modified), old_api.py (left only),
   new_feature.py (right only), utils/helper.py (modified).

3. FILE COMPARE (⌘4)
   Press ⌘4. Drag file_a.txt into left, file_b.txt into right.

4. BINARY COMPARE (⌘5)
   Press ⌘5. Drag binary_a.bin into left, binary_b.bin into right.

5. SEARCH (⌘6)
   Press ⌘6. Add 'search_target/' folder. Search for 'hello'.

CONTACT
-------
lode@rexcode.app | https://rexcode.app/lode/support/
