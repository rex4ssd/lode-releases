# shared utility
def greet(name):
    return f'Hello, {name}!'
