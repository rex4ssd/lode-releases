VERSION = '0.9.0'
DEBUG = True
MAX_RETRIES = 3

def run():
    print('starting v0.9')
