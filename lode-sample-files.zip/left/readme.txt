Lode Folder Compare sample.
Drag left/ and right/ into Lode ⌘3.
