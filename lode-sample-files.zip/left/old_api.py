# deprecated — only in left
def old_func():
    pass
